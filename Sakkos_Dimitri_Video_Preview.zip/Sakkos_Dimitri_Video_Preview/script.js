// hover over video preview 
function over(element) {
	play("myvideo");
}
// hover off video to pause preview
function out(element) {
	pause("myvideo");
}

